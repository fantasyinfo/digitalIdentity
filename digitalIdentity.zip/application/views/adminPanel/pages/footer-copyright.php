  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; <?=date('jS F Y H:i A');?> <a href="<?=HelperClass::brandUrl?>"  target="_blank"><?=HelperClass::brandName?></a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
  </footer>