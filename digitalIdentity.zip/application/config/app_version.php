<?php

$config['app'] = array();
$config['app']['connect'] = array(
    'live' => array(
        		'version_code' => ['3'],
        		'version_name' => ['1.0.3'],
        		'is_compulsary' => 1,
        		'link' => 'https://drive.google.com/file/d/119sn2oyLt6Y5ehdW6MZSjGn2horVjtiQ/view?usp=sharing',
        		'playstore' => 'https://play.google.com/store/apps/details?id=com.digitalfied.di'
        	),
);